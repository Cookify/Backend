class Package < ActiveRecord::Base
  belongs_to :provider
end
