class ProviderRating < ActiveRecord::Base
  belongs_to :provider
end
