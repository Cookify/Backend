require 'test_helper'

class Api::V1::ProviderControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
